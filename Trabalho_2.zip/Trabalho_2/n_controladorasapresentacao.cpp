#include "n_controladorasapresentacao.h"

//--------------------------------------------------------------------------------------------
// Implementa��es dos m�todos das classes controladoras da camada de apresenta��o.


//--------------------------------------------------------------------------------------------
// Implementa��es dos m�todos da classe controladora apresenta��o controle.

void CntrApresentacaoControle::executar(){

    // Mensagens a serem apresentadas na tela inicial.

    char texto1[] = "Selecione um dos servicos : ";
    char texto2[] = "1 - Acessar sistema.";
    char texto3[] = "2 - Cadastrar usuario.";
    char texto4[] = "3 - Listar imoveis disponiveis.";
    char texto5[] = "4 - Encerrar execucao do sistema.";

    // Mensagens a serem apresentadas na tela de sele��o de servi�o.

    char texto6[] = "Selecione um dos servicos : ";

    char texto7[] = "1 - Acessar servicos relacionados a Conta.";
    char texto8[] = "2 - Acessar servicos relacionados a Imovel.";
    char texto9[] = "3 - Acessar servicos relacionados a Proposta.";
    char texto11[] = "4 - Acessar servicos relacionados a Meus Imoveis Cadastrados.";
    char texto12[] = "5 - Retornar ao menu inicial.";

    char texto10[] = "Falha na autenticacao. Digite algo para continuar.";                        // Mensagem a ser apresentada.

    int campo = 0;                                                                                  // Campo de entrada.

    bool apresentar = true;                                                                     // Controle de la�o.

    while(apresentar){

        // Apresenta tela inicial.

        CLR_SCR;                                                                                // Limpa janela.

        cout << texto1 << endl;                                                                 // Imprime nome do campo.
        cout << texto2 << endl;                                                                 // Imprime nome do campo.
        cout << texto3 << endl;
        cout << texto4 << endl;                                                                 // Imprime nome do campo.
        cout << texto5 << endl;                                                                 // Imprime nome do campo.

        campo = getch() - 48;                                                                   // Leitura do campo de entrada e convers�o de ASCII.

        switch(campo){
            case 1: if(cntrApresentacaoAutenticacao->autenticar(&email)){                         // Solicita autentica��o.
                        bool apresentar = true;                                                 // Controle de la�o.
                        while(apresentar){

                            // Apresenta tela de sele��o de servi�o.

                            CLR_SCR;                                                            // Limpa janela.

                            cout << texto6 << endl;                                             // Imprime nome do campo.
                            cout << texto7 << endl;
                            cout << texto8 << endl;
                            cout << texto9 << endl;
                            cout << texto11 << endl;
                            cout << texto12 << endl;

                            campo = getch() - 48;                                               // Leitura do campo de entrada e convers�o de ASCII.

                            switch(campo){
                                case 1: cntrApresentacaoPessoal->executar(email);                 // Solicita servi�o de pessoal.
                                        break;
                                case 2: cntrApresentacaoImoveis->executar_1(email);     // Solicita servi�o de produto financeiro.
                                        break;
                                case 3: cntrApresentacaoImoveis->executar_2(email);     // Solicita servi�o de produto financeiro.
                                        break;
                                case 4: cntrApresentacaoImoveis->executar_3(email);     // Solicita servi�o de produto financeiro.
                                        break;
                                case 5: apresentar = false;
                                        break;
                            }
                        }
                    }
                    else {
                        CLR_SCR;                                                                // Limpa janela.
                        cout << texto10 << endl;                                                // Imprime mensagem.
                        getch();                                                                // Leitura de caracter digitado.
                    }
                    break;
            case 2: cntrApresentacaoPessoal->cadastrar();
                    break;
            case 3: cntrApresentacaoImoveis->executar();
                    break;
            case 4: apresentar = false;
                    cout << "Programa encerrado." << endl;
                    break;
        }
    }
    return;
}

//--------------------------------------------------------------------------------------------
// Implementa��es dos m�todos da classe controladora apresenta��o autentica��o.

bool CntrApresentacaoAutenticacao::autenticar(Email *email){

    // Mensagens a serem apresentadas na tela de autentica��o.

    char texto1[] = "Digite o email  : ";
    char texto2[] = "Digite a senha  : ";
    char texto3[] = "Dado em formato incorreto. Digite algo.";

    // Campos de entrada.

    string campo1(""), campo2("");

    Senha senha;                                                                                // Instancia a classe Senha.

    int contador = 0;

    while(true){

        // Apresenta tela de autentica��o.
        CLR_SCR;                                                                                // Limpa janela.
        /*while(contador == 0){
            if(contador <= 0){
                cout << texto1 << " ";
                contador_2 ++;
            }if(contador_2 > 0){
                cout << texto1 << " ";
                break;
            }
                                                                                                    // Imprime nome do campo.
            cin >> campo1;                                                                          // L� valor do campo.
            cout << texto2 << " ";                                                                  // Imprime nome do campo.
            cin >> campo2;
        }*/
        if(contador == 0){
            cout << texto1 << " ";
        }else{
            cout << "Digite o email  : " << " ";
        }
        cin >> campo1;                                                                          // L� valor do campo.
        cout << texto2 << " ";                                                                  // Imprime nome do campo.
        cin >> campo2;                                                                          // L� valor do campo.

        try{
            email->setValor(campo1);                                                    // Atribui valor ao email.
            senha.setValor_2(campo2);                                                   // Atribui Valor � senha.
            break;                                                                              // Abandona la�o em caso de formatos corretos.
        }
        catch(invalid_argument &exp){                                                           // Captura exce��o devido a formato incorreto.
            CLR_SCR;                                                                            // Limpa janela.
            cout << texto3 << endl;                                                             // Informa formato incorreto.
            getch();                                                                            // L� caracter digitado.
        }
        contador++;
    }
    return (cntr->autenticar(*email, senha));                                                     // Solicita servi�o de autentica��o.
}

//--------------------------------------------------------------------------------------------
// Implementa��es dos m�todos da classe controladora apresenta��o pessoal.

void CntrApresentacaoPessoal::executar(Email email){

    // Mensagens a serem apresentadas na tela de sele��o de servi�o..

    char texto1[] = "Selecione um dos servicos : ";
    char texto2[] = "1 - Descadastrar conta.";
    char texto3[] = "2 - Editar dados da conta.";
    char texto4[] = "3 - Retornar.";

    int campo = 0;                                                                                  // Campo de entrada.

    bool apresentar = true;
    bool bandeira = false;                                                                   // Controle de la�o.

    while(apresentar){
        if (bandeira){
            break;
        }
        // Apresenta tela de sela��o de servi�o.

        CLR_SCR;                                                                                // Limpa janela.

        cout << texto1 << endl;                                                                 // Imprime nome do campo.
        cout << texto2 << endl;                                                                 // Imprime nome do campo.
        cout << texto3 << endl;
        cout << texto4 << endl;                                                                    // Imprime nome do campo.

        campo = getch() - 48;                                                                   // Leitura do campo de entrada e convers�o de ASCII.

        switch(campo){
            case 1: descadastrarConta();
                    bandeira = true;
                    break;
            case 2: alterar();
                    break;
            case 3: apresentar = false;
                    break;
        }
    }
}

//--------------------------------------------------------------------------------------------

void CntrApresentacaoPessoal::cadastrar(){

    // Mensagens a serem apresentadas na tela de cadastramento.

    char texto1[] = "Preencha os seguintes campos: ";
    char texto2[] = "Nome            :";
    char texto3[] = "email           :";
    char texto4[] = "Senha           :";
    char texto5[] = "Telefone        :";
    char texto10[] = "Dados em formato incorreto. Digite algo para voltar para o menu incial.";
    char texto11[] = "Sucesso no cadastramento. Digite algo.";
    char texto12[] = "Falha no cadastramento. Digite algo.";

    char campo1[80], campo2[80], campo3[6], campo4[80];                           // Cria campos para entrada dos dados.

    // Instancia os dom�nios.

    Nome nome;
    Email email;
    Senha senha;
    Telefone telefone;

    // Apresenta tela de cadastramento.

    CLR_SCR;                                                                                   // Limpa janela.

    cout << texto1 << endl;                                                                    // Imprime solicita��o ao usu�rio.
    cout << texto2 << " ";                                                                     // Imprime nome do campo.
    cin >> campo1;                                                                             // L� valor do campo.
    cout << texto3 << " ";                                                                     // Imprime nome do campo.
    cin >> campo2;                                                                             // L� valor do campo.
    cout << texto4 << " ";
    cin >> campo3;                                                                             // L� valor do campo.
    cout << texto5 << " ";                                                                     // Imprime nome do campo.
    cin >> campo4;

    try{
        nome.setValor(string(campo1));
        email.setValor(string(campo2));
        senha.setValor_1(string(campo3));
        telefone.setValor(string(campo4));
    }
    catch(invalid_argument &exp){                                                             // Informa formato incorreto.
        getch();                                                                                // Leitura de caracter digitado.
        return;
    }

    // Instancia e inicializa entidades.

    Usuario usuario;

    usuario.setnome(nome);
    usuario.setemail(email);
    usuario.setsenha(senha);
    usuario.settelefone(telefone);

    // Cadastra usu�rio e conta.

    //if(cntrServicoPessoal->cadastrarUsuario(usuario))
        /*if(cntrServicoImoveis->cadastrarConta(conta)){
            cout << texto11 << endl;                                                                    // Informa sucesso.
            getch();
            return;
        }*/

    /*cout << texto12 << endl;                                                                            // Informa falha.
    getch();*/
    cout << texto11 << endl;
    getch();

    return;
}

//--------------------------------------------------------------------------------------------

void CntrApresentacaoPessoal::descadastrarConta(){
    char texto1[] = "Quando uma conta e descadastrada, sao descadastrados os imoveis e as propostas de aluguel associadas a ela.";
    char texto2[] = "Voce tem certeza que deseja descadastar a conta?";
    char texto3[] = "Digite 1, se sim e 2, caso nao.";
    char texto4[] = "Dado em formato incorreto. Digite algo.";
    int campo = 0;

    bool apresentar = true; // Controle de la�o.
    bool bandeira = false;

    while(apresentar){
        if (bandeira){
            break;
        }
         // Apresenta tela de sela��o de servi�o.

        CLR_SCR; // Limpa janela.

        cout << texto1 << endl;
        cout << texto2 << endl;
        cout << texto3 << endl;

        campo = getch() - 48; // Leitura do campo de entrada e convers�o de ASCII.

        switch(campo){
            case 1: cout << "Conta descadastrada com sucesso." << endl;
                Sleep(3000);
                bandeira = true;
                break;
            case 2: apresentar = false;
                break;
            default:
                cout << texto4 << endl;
                break;
        }
    }
}

void CntrApresentacaoPessoal::alterar(){
    char texto1[] = "Digite 1, caso queira editar os dados da sua conta e 2, caso contrario.";
    char texto2[] = "Dado em formato incorreto. Digite algo.";
    int campo1 = 0;
    char campo2[80], campo3[80], campo4[80], campo5[80];

    bool apresentar = true; // Controle de la�o.
    bool bandeira = false;

    Nome nome;
    Email email;
    Senha senha;
    Telefone telefone;

    while(apresentar){
        if(bandeira){
            break;
        }
         // Apresenta tela de sela��o de servi�o.

        CLR_SCR; // Limpa janela.

        cout << texto1 << endl;

        campo1 = getch() - 48; // Leitura do campo de entrada e convers�o de ASCII.

        switch(campo1){
            case 1:
                while(true){
                    cout << "Digite um novo nome: " << " ";
                    cin >> campo2;
                    cout << "Digite um novo email: " << " ";
                    cin >> campo3;
                    cout << "Digite uma nova senha: " << " ";
                    cin >> campo4;
                    cout << "Digite um novo telefone: " << " ";
                    cin >> campo5;

                    try{
                        nome.setValor(string(campo2));
                        email.setValor(string(campo3));
                        senha.setValor_2(string(campo4));
                        telefone.setValor(string(campo5));

                        break;
                    }
                    catch(invalid_argument &exp){                                                             // Informa formato incorreto.
                        cout << texto2 << endl;
                        getch();                                                                                // Leitura de caracter digitado.
                    }
                }
                bandeira = true;

                cout << "Dados atualizados com sucesso." << endl;

                Sleep(3000);

                break;
            case 2: apresentar = false;
                break;
            default:
                cout << texto2 << endl;
                break;
        }
    }
}

//--------------------------------------------------------------------------------------------

void CntrApresentacaoImoveis::executar(){

    // Mensagens a serem apresentadas na tela simplificada de imoveis.

    char texto1[] = "Selecione um dos servicos : ";
    char texto2[] = "1 - Apresentar dados de Imovel.";
    char texto3[] = "2 - Retornar para o menu inicial.";

    int campo = 0;                                                                                  // Campo de entrada.

    bool apresentar = true;                                                                     // Controle de la�o.

    while(apresentar){

        // Apresenta tela simplificada de imoveis.

        CLR_SCR;                                                                                // Limpa janela.

        cout << texto1 << endl;                                                                 // Imprime nome do campo.
        cout << texto2 << endl;                                                                 // Imprime nome do campo.
        cout << texto3 << endl;                                                                 // Imprime nome do campo.

        campo = getch() - 48;                                                                   // Leitura do campo de entrada.

        switch(campo){
            case 1: consultarImovel();
                    break;
            case 2: apresentar = false;
                    break;
        }
    }
}

//--------------------------------------------------------------------------------------------

void CntrApresentacaoImoveis::executar_1(Email){

    // Mensagens a serem apresentadas tela completa de imoveis.

    char texto1[] = "Selecione um dos servicos : ";
    char texto2[] = "1 - Cadastrar Imovel.";
    char texto3[] = "2 - Descadastrar Imovel.";
    char texto4[] = "3 - Editar Dados De Imovel.";
    char texto5[] = "4 - Retornar.";

    int campo = 0;                                                                                  // Campo de entrada.

    bool apresentar = true;
    bool bandeira = false;                                                                     // Controle de la�o.

    while(apresentar){
        if (bandeira){
            break;
        }
        // Apresenta tela completa de imoveis.

        CLR_SCR;                                                                                // Limpa janela.

        cout << texto1 << endl;                                                                 // Imprime nome do campo.
        cout << texto2 << endl;                                                                 // Imprime nome do campo.
        cout << texto3 << endl;                                                                 // Imprime nome do campo.
        cout << texto4 << endl;
        cout << texto5 << endl;                                                                                                                                  // Imprime nome do campo.                                                                 // Imprime nome do campo.

        campo = getch() - 48;                                                                   // Leitura do campo de entrada e convers�o de ASCII.

        switch(campo){
            case 1: cadastrarImovel();
                    break;
            case 2: descadastrarImovel();
                    bandeira = true;

                    break;
            case 3: editarDadosDeImovel();
                    break;
            case 4: bandeira = true;
                    break;
        }
    }
}

void CntrApresentacaoImoveis::executar_2(Email){

    // Mensagens a serem apresentadas tela completa de imoveis.

    char texto1[] = "Selecione um dos servicos : ";
    char texto2[] = "1 - Cadastrar Proposta de aluguel.";
    char texto3[] = "2 - Listar as propostas de aluguel.";
    char texto4[] = "3 - Apresentar dados de proposta de aluguel.";
    char texto5[] = "4 - Descadastrar Proposta de aluguel.";
    char texto6[] = "5 - Retornar.";

    int campo = 0;                                                                                  // Campo de entrada.

    bool apresentar = true;
    bool bandeira = false;                                                                     // Controle de la�o.

    while(apresentar){
        if (bandeira){
            break;
        }
        // Apresenta tela completa de imoveis.

        CLR_SCR;                                                                                // Limpa janela.

        cout << texto1 << endl;                                                                 // Imprime nome do campo.
        cout << texto2 << endl;                                                                 // Imprime nome do campo.
        cout << texto3 << endl;                                                                 // Imprime nome do campo.
        cout << texto4 << endl;
        cout << texto5 << endl;                                                                 // Imprime nome do campo.                                                                 // Imprime nome do campo.
        cout << texto6 << endl;

        campo = getch() - 48;                                                                   // Leitura do campo de entrada e convers�o de ASCII.

        switch(campo){
            case 1: cadastrarProposta();
                    break;
            case 2: listarPropostas();
                    bandeira = true;

                    break;
            case 3: apresentarPropostas();;
                    break;
            case 4: descadastrarProposta();;
                    break;
            case 5: bandeira = true;
                    break;
        }
    }
}

void CntrApresentacaoImoveis::executar_3(Email){

    // Mensagens a serem apresentadas tela completa de imoveis.

    char texto1[] = "Selecione um dos servicos : ";
    char texto2[] = "1 - Listar todas as propostas de aluguel que estao associadas ao/aos imovel/imoveis cadastrado/cadastrados por voce.";
    char texto3[] = "2 - Acessar dados de cada proposta de aluguel associada ao/aos imovel/imoveis cadastrado/cadastrados por voce.";
    char texto4[] = "3 - Retornar.";

    int campo = 0;                                                                                  // Campo de entrada.

    bool apresentar = true;
    bool bandeira = false;                                                                     // Controle de la�o.

    while(apresentar){
        if (bandeira){
            break;
        }
        // Apresenta tela completa de imoveis.

        CLR_SCR;                                                                                // Limpa janela.

        cout << texto1 << endl;                                                                 // Imprime nome do campo.
        cout << texto2 << endl;                                                                 // Imprime nome do campo.
        cout << texto3 << endl;
        cout << texto4 << endl;                                                                   // Imprime nome do campo.
        //cout << texto4 << endl;                                                                 // Imprime nome do campo.                                                                 // Imprime nome do campo.

        campo = getch() - 48;                                                                   // Leitura do campo de entrada e convers�o de ASCII.

        switch(campo){
            case 1: cout << "Servico de listagem de propostas de aluguel associadas nao implementado." << endl;
                    break;
            case 2: cout << "Servico de listagem de dados de propostas de aluguel associadas nao implementado." << endl;
                    bandeira = true;

                    break;
            case 3: bandeira = true;
                    break;
        }
    }
}

//--------------------------------------------------------------------------------------------

void CntrApresentacaoImoveis::consultarConta(){

    //--------------------------------------------------------------------------------------------
    //--------------------------------------------------------------------------------------------
    // Substituir c�digo seguinte pela implementa��o do m�todo.
    //--------------------------------------------------------------------------------------------
    //--------------------------------------------------------------------------------------------

    // Mensagens a serem apresentadas.

    char texto[] = "Servico consultar conta nao implementado. Digite algo.";                      // Mensagem a ser apresentada.

    CLR_SCR;                                                                                    // Limpa janela.
    cout << texto << endl;                                                                      // Imprime nome do campo.
    getch();
}

//--------------------------------------------------------------------------------------------

void CntrApresentacaoImoveis::cadastrarImovel(){
    // Mensagens a serem apresentadas na tela de cadastramento.
    char texto1[] = "Preencha os seguintes campos:";
    char texto2[] = "Classe do imovel:\n1 -> apartamento, 2 -> casa, 3 -> quarto  :";
    char texto3[] = "Descricao                                 :";
    char texto4[] = "Endereco                                  :";
    char texto5[] = "Numero maximo de hospedes                 :";
    char texto6[] = "Data inicial do periodo de disponibilidade:";
    char texto7[] = "Data final do periodo de disponibilidade  :";
    char texto8[] = "Valor de diaria minimo                    :";

    char texto9[] = "Dados em formato incorreto. Digite algo para voltar para o menu incial.";
    char texto10[] = "Sucesso no cadastramento. Digite algo.";
    char texto11[] = "Falha no cadastramento. Digite algo.";

    int campo1 = 0;
    int campo4 = 0;
    int campo7 = 0;

    string campo2("");
    string campo3("");
    string campo5("");
    string campo6("");

    // Cria campos para entrada dos dados.

    // Instancia os dom�nios.

    Classe classe;
    Codigo codigo;
    Descricao descricao;
    Endereco endereco;
    Data data_inicial;
    Data data_final;
    Numero hospedes;
    Moeda valor;

    // Apresenta tela de cadastramento.

    CLR_SCR;                                                                                   // Limpa janela.

    cout << texto1 << endl;                                                                    // Imprime solicita��o ao usu�rio.
    cout << texto2 << " ";                                                                     // Imprime nome do campo.
    cin >> campo1;
    cin.ignore();

    try{
        classe.setValor(int(campo1));
    }catch(invalid_argument &exp){
        cout << texto9 << endl;                                                             // Informa formato incorreto.
        getch();                                                                                // Leitura de caracter digitado.
        return;
    }
                                                                                     // L� valor do campo.
    cout << texto3 << " ";
                                                                      // Imprime nome do campo
    getline(cin, campo2);

    try{
        descricao.setValor(string(campo2));
    }catch(invalid_argument &exp){
        cout << texto9 << endl;                                                             // Informa formato incorreto.
        getch();                                                                                // Leitura de caracter digitado.
        return;
    }
                                                                                 // L� valor do campo.
    cout << texto4 << " ";

    getline(cin, campo3);

    try{
        endereco.setValor(string(campo3));
    }catch(invalid_argument &exp){
        cout << texto9 << endl;                                                             // Informa formato incorreto.
        getch();                                                                                // Leitura de caracter digitado.
        return;
    }
                                                                                    // L� valor do campo.
    cout << texto5 << " ";                                                                     // Imprime nome do campo.
    cin >> campo4;
    cin.ignore();

    try{
        hospedes.setValor(int(campo4));
    }catch(invalid_argument &exp){
        cout << texto9 << endl;                                                             // Informa formato incorreto.
        getch();                                                                                // Leitura de caracter digitado.
        return;
    }

    cout << texto6 << " ";
                                                                      // Imprime nome do campo.
    getline(cin, campo5);

    try{
        data_inicial.setValor(string(campo5));
    }catch(invalid_argument &exp){
        cout << texto9 << endl;                                                             // Informa formato incorreto.
        getch();                                                                                // Leitura de caracter digitado.
        return;
    }

    cout << texto7 << " ";
                                                                      // Imprime nome do campo.
    getline(cin, campo6);

    try{
        data_final.setValor(string(campo6));
    }catch(invalid_argument &exp){
        cout << texto9 << endl;                                                             // Informa formato incorreto.
        getch();                                                                                // Leitura de caracter digitado.
        return;
    }

    cout << texto8 << " ";                                                                     // Imprime nome do campo.
    cin >> campo7;
    cin.ignore();

    try{
        valor.setValor(int(campo7));
    }catch(invalid_argument &exp){
        cout << texto9 << endl;                                                             // Informa formato incorreto.
        getch();                                                                                // Leitura de caracter digitado.
        return;
    }

    // Instancia e inicializa entidades.

    Imovel imovel;

    imovel.setclasse(classe);
    imovel.setdescricao(descricao);
    imovel.setendereco(endereco);
    imovel.sethospedes(hospedes);
    imovel.setdata_inicial(data_inicial);
    imovel.setdata_final(data_final);
    imovel.setvalor(valor);

    // Cadastra usu�rio e conta.

    //if(cntrServicoPessoal->cadastrarUsuario(usuario))
        /*if(cntrServicoImoveis->cadastrarConta(conta)){
            cout << texto11 << endl;                                                                    // Informa sucesso.
            getch();
            return;
        }*/

    /*cout << texto12 << endl;                                                                            // Informa falha.
    getch();*/
    cout << texto10 << endl;
    getch();

    return;
}

//--------------------------------------------------------------------------------------------

void CntrApresentacaoImoveis::descadastrarImovel(){
    char texto1[] = "Quando um imovel e descadastrado, sao tambem descadastradas as propostas de aluguel associadas ao imovel.";
    char texto2[] = "Voce tem certeza que deseja descadastar o imovel?";
    char texto3[] = "Digite 1, se sim e 2, caso nao.";
    char texto4[] = "Dado em formato incorreto. Digite algo.";
    int campo = 0;

    bool apresentar = true; // Controle de la�o.
    bool bandeira = false;

    while(apresentar){
        if (bandeira){
            break;
        }
         // Apresenta tela de sela��o de servi�o.

        CLR_SCR; // Limpa janela.

        cout << texto1 << endl;
        cout << texto2 << endl;
        cout << texto3 << endl;

        campo = getch() - 48; // Leitura do campo de entrada e convers�o de ASCII.

        switch(campo){
            case 1: cout << "Imovel descadastrado com sucesso." << endl;
                Sleep(3000);
                bandeira = true;
                break;
            case 2: apresentar = false;
                break;
            default:
                cout << texto4 << endl;
                break;
        }
    }
}

void CntrApresentacaoImoveis::editarDadosDeImovel(){
    char texto1[] = "Digite 1, caso queira editar os dados do imovel cadastrado e 2, caso contrario.";
    char texto2[] = "Dado em formato incorreto. Digite algo.";

    char texto3[] = "Digite uma nova Classe do imovel:\n1 -> apartamento, 2 -> casa, 3 -> quarto                  :";
    char texto4[] = "Digite uma nova Descricao                                 :";
    char texto5[] = "Digite um novo Endereco                                   :";
    char texto6[] = "Digite um novo Numero maximo de hospedes                  :";
    char texto7[] = "Digite uma nova Data inicial do periodo de disponibilidade:";
    char texto8[] = "Digite uma nova Data final do periodo de disponibilidade  :";
    char texto9[] = "Digite um novo Valor de diaria minimo                     :";

    char texto10[] = "Sucesso na edicao de dados de imovel. Digite algo.";
    char texto11[] = "Falha na edicao de dados de imovel. Digite algo.";

    int campo1 = 0, campo4 = 0, campo7 = 0;
    string campo2(""), campo3(""), campo5(""), campo6("");

    bool apresentar = true; // Controle de la�o.
    bool bandeira = false;

    Classe classe;
    Codigo codigo;
    Descricao descricao;
    Endereco endereco;
    Data data_inicial;
    Data data_final;
    Numero hospedes;
    Moeda valor;

    while(apresentar){
        if(bandeira){
            break;
        }
         // Apresenta tela de sela��o de servi�o.

        CLR_SCR; // Limpa janela.

        cout << texto1 << endl;

        campo1 = getch() - 48; // Leitura do campo de entrada e convers�o de ASCII.

        switch(campo1){
            case 1:
                while(true){
                    // Apresenta tela de cadastramento.

                    CLR_SCR;
                                                                                                       // Limpa janela.// Imprime solicita��o ao usu�rio.
                    cout << texto3 << " ";                                                                     // Imprime nome do campo.
                    cin >> campo1;
                    cin.ignore();

                    try{
                        classe.setValor(campo1);
                    }catch(invalid_argument &exp){
                        cout << "erro1" << endl;
                        cout << texto2 << endl;                                                             // Informa formato incorreto.
                        getch();                                                                                // Leitura de caracter digitado.
                        return;
                    }
                                                                                                     // L� valor do campo.
                    cout << texto4 << " ";
                                                                                      // Imprime nome do campo
                    getline(cin, campo2);

                    try{
                        descricao.setValor(campo2);
                    }catch(invalid_argument &exp){
                        cout << "erro2" << endl;
                        cout << texto2 << endl;                                                             // Informa formato incorreto.
                        getch();                                                                                // Leitura de caracter digitado.
                        return;
                    }
                                                                                                 // L� valor do campo.
                    cout << texto5 << " ";

                    getline(cin, campo3);

                    try{
                        endereco.setValor(campo3);
                    }catch(invalid_argument &exp){
                        cout << "erro3" << endl;
                        cout << texto2 << endl;                                                             // Informa formato incorreto.
                        getch();                                                                                // Leitura de caracter digitado.
                        return;
                    }
                                                                                                    // L� valor do campo.
                    cout << texto6 << " ";                                                                     // Imprime nome do campo.
                    cin >> campo4;
                    cin.ignore();

                    try{
                        hospedes.setValor(campo4);
                    }catch(invalid_argument &exp){
                        cout << "erro4" << endl;
                        cout << texto2 << endl;                                                             // Informa formato incorreto.
                        getch();                                                                                // Leitura de caracter digitado.
                        return;
                    }

                    cout << texto7 << " ";
                                                                                      // Imprime nome do campo.
                    getline(cin, campo5);

                    try{
                        data_inicial.setValor(campo5);
                    }catch(invalid_argument &exp){
                        cout << "erro5" << endl;
                        cout << texto2 << endl;                                                             // Informa formato incorreto.
                        getch();                                                                                // Leitura de caracter digitado.
                        return;
                    }

                    cout << texto8 << " ";
                                                                                      // Imprime nome do campo.
                    getline(cin, campo6);

                    try{
                        data_final.setValor(campo6);
                    }catch(invalid_argument &exp){
                        cout << "erro6" << endl;
                        cout << texto2 << endl;                                                             // Informa formato incorreto.
                        getch();                                                                                // Leitura de caracter digitado.
                        return;
                    }

                    cout << texto9 << " ";                                                                     // Imprime nome do campo.
                    cin >> campo7;
                    cin.ignore();

                    try{
                        valor.setValor(campo7);
                    }catch(invalid_argument &exp){
                        cout << "erro7" << endl;
                        cout << texto2 << endl;                                                             // Informa formato incorreto.
                        getch();                                                                                // Leitura de caracter digitado.
                        return;
                    }

                    // Instancia e inicializa entidades.

                    Imovel imovel;

                    imovel.setclasse(classe);
                    imovel.setdescricao(descricao);
                    imovel.setendereco(endereco);
                    imovel.sethospedes(hospedes);
                    imovel.setdata_inicial(data_inicial);
                    imovel.setdata_final(data_final);
                    imovel.setvalor(valor);

                    // Cadastra usu�rio e conta.

                    //if(cntrServicoPessoal->cadastrarUsuario(usuario))
                        /*if(cntrServicoImoveis->cadastrarConta(conta)){
                            cout << texto11 << endl;                                                                    // Informa sucesso.
                            getch();
                            return;
                        }*/

                    /*cout << texto12 << endl;                                                                            // Informa falha.
                    getch();*/
                    cout << texto10 << endl;
                    getch();

                    break;
                }

                bandeira = true;

                break;
            case 2: apresentar = false;
                break;
            default:
                cout << texto2 << endl;
                break;
        }
    }
}

//--------------------------------------------------------------------------------------------

void CntrApresentacaoImoveis::consultarImovel(){

    //--------------------------------------------------------------------------------------------
    //--------------------------------------------------------------------------------------------
    // Substituir c�digo seguinte pela implementa��o do m�todo.
    //--------------------------------------------------------------------------------------------
    //--------------------------------------------------------------------------------------------

    // Mensagens a serem apresentadas.

    char texto[] = "Servico consultar imovel nao implementado. Digite algo.";       // Mensagem a ser apresentada.

    CLR_SCR;                                                                                    // Limpa janela.
    cout << texto << endl;                                                                      // Imprime nome do campo.
    getch();

}

//--------------------------------------------------------------------------------------------

void CntrApresentacaoImoveis::cadastrarProposta(){
    char texto1[] = "Preencha os seguintes campos:";
    char texto2[] = "Data inicial do periodo de aluguel:";
    char texto3[] = "Data final do periodo de aluguel  :";
    char texto4[] = "Numero de hospedes                :";
    char texto5[] = "Valor de diaria proposto          :";

    char texto6[] = "Falha no cadastramento de proposta. Dados em formato incorreto. Digite algo para voltar.";
    char texto7[] = "Sucesso no cadastramento de proposta. Digite algo.";

    string campo1("");
    string campo2("");
    int campo3 = 0;
    int campo4 = 0;

    Data data_inicial;
    Data data_final;
    Numero hospedes;
    Moeda valor;

    CLR_SCR;                                                                                   // Limpa janela.

    cout << texto1 << endl;                                                                    // Imprime solicita��o ao usu�rio.
    cout << texto2 << " ";                                                                     // Imprime nome do campo.

    getline(cin, campo1);

    try{
        data_inicial.setValor(campo1);
    }catch(invalid_argument &exp){
        cout << texto6 << endl;                                                             // Informa formato incorreto.
        getch();                                                                                // Leitura de caracter digitado.
        return;
    }

    cout << texto3 << " ";                                                                     // Imprime nome do campo.

    getline(cin, campo2);

    try{
        data_final.setValor(campo2);
    }catch(invalid_argument &exp){
        cout << texto6 << endl;                                                             // Informa formato incorreto.
        getch();                                                                                // Leitura de caracter digitado.
        return;
    }
                                                                                     // L� valor do campo
    cout << texto4 << " ";

    cin >> campo3;
    cin.ignore();

    try{
        hospedes.setValor(campo3);
    }catch(invalid_argument &exp){
        cout << texto6 << endl;                                                             // Informa formato incorreto.
        getch();                                                                                // Leitura de caracter digitado.
        return;
    }
                                                                                    // L� valor do campo.
    cout << texto5 << " ";

    cin >> campo4;
    cin.ignore();

    try{
        valor.setValor(campo4);
    }catch(invalid_argument &exp){
        cout << texto6 << endl;                                                             // Informa formato incorreto.
        getch();                                                                                // Leitura de caracter digitado.
        return;
    }

    cout << texto7 << endl;
    getch();
    return;
}

//--------------------------------------------------------------------------------------------

void CntrApresentacaoImoveis::listarPropostas(){

    //--------------------------------------------------------------------------------------------
    //--------------------------------------------------------------------------------------------
    // Substituir c�digo seguinte pela implementa��o do m�todo.
    //--------------------------------------------------------------------------------------------
    //--------------------------------------------------------------------------------------------

    // Mensagens a serem apresentadas.

    char texto[] = "Servico listar propostas nao implementado. Digite algo.";                    // Mensagem a ser apresentada.

    CLR_SCR;                                                                                    // Limpa janela.
    cout << texto << endl;                                                                      // Imprime nome do campo.
    getch();

}

void CntrApresentacaoImoveis::apresentarPropostas(){

    //--------------------------------------------------------------------------------------------
    //--------------------------------------------------------------------------------------------
    // Substituir c�digo seguinte pela implementa��o do m�todo.
    //--------------------------------------------------------------------------------------------
    //--------------------------------------------------------------------------------------------

    // Mensagens a serem apresentadas.

    char texto[] = "Servico listar propostas nao implementado. Digite algo.";                    // Mensagem a ser apresentada.

    CLR_SCR;                                                                                    // Limpa janela.
    cout << texto << endl;                                                                      // Imprime nome do campo.
    getch();

}

void CntrApresentacaoImoveis::descadastrarProposta(){
    char texto1[] = "Voce tem certeza que deseja descadastar a proposta?";
    char texto2[] = "Digite 1, se sim e 2, caso nao.";
    char texto3[] = "Dado em formato incorreto. Digite algo.";

    int campo = 0;

    bool apresentar = true; // Controle de la�o.
    bool bandeira = false;

    while(apresentar){
        if (bandeira){
            break;
        }
         // Apresenta tela de sela��o de servi�o.

        CLR_SCR; // Limpa janela.

        cout << texto1 << endl;
        cout << texto2 << endl;

        campo = getch() - 48; // Leitura do campo de entrada e convers�o de ASCII.

        switch(campo){
            case 1: cout << "Proposta descadastrada com sucesso." << endl;
                Sleep(3000);
                bandeira = true;
                break;
            case 2: apresentar = false;
                bandeira = true;
                break;
            default:
                cout << texto3 << endl;
                break;
        }
    }
}
