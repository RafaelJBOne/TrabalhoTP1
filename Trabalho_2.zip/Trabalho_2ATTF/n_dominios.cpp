#include "n_dominios.h"

const string Codigo::DEFAULT = "XXXXX";
const string Descricao::DEFAULT = "12345.";
const string Endereco::DEFAULT = "Conj 08 lote 14.5";
const string Data::DEFAULT = "16-03-21";
const double Moeda::DEFAULT = 100;
const string Nome::DEFAULT = "Johnatan";
const string Email::DEFAULT = "nome@dom�nio";
const string Senha::DEFAULT = "AB1sCD";
const string Telefone::DEFAULT = "(123)-123456789";

Codigo::Codigo(){
    valor = DEFAULT;
}

Codigo::Codigo(string valor){
    this->valor = valor;
}

void Codigo::setValor(string valor){
    if (validar(valor)){
        this->valor = valor;
    }else{
        throw invalid_argument("Argumento invalido.");
    }
}

bool Codigo::validar(string valor){
   int i = 0;

   if(valor[0] == 48 && valor[1] == 48 && valor[2] == 48 && valor[3]== 48 && valor[4]== 48){
        return false;
   }
   while(valor[i] != '\0'){
        if (valor[i] >= 65 && valor[i] <= 90){
            i++;
            continue;
        }
        if (valor[i] >= 48 && valor[i] <= 57){
            i++;
            continue;
        }
        if (valor[i] < 65 || valor[i] > 90 || valor[i] < 48 || valor[i] > 57){
            i++;
            return false;
        }
   }
    if(i != 5){
        return false;
    }
    return true;
}

Classe::Classe(){
    valor = DEFAULT;
}

Classe::Classe(int valor){
    this->valor = valor;
}

void Classe::setValor(int valor){
    if (validar(valor)){
        this->valor = valor;
    }else{
        throw invalid_argument("Argumento invalido.");
    }
}

bool Classe::validar(int valor){

    switch(valor){
        case 1:

            return true;
        break;

        case 2:
            return true;
        break;

        case 3:
            return true;
        break;

        default:
            return false;
        break;
    }
    return true;
}

Descricao::Descricao(){
    valor = DEFAULT;
}

Descricao::Descricao(string valor){
    this->valor = valor;
}

void Descricao::setValor(string valor){
    if (validar(valor)){
        this->valor = valor;
    }else{
        throw invalid_argument("Argumento invalido.");
    }
}

bool Descricao::validar(string valor){

    int contador = 0;

    while (valor[contador] != '\0' && contador <= 30){
        contador ++;
    }

    if (contador < 5 or contador > 30 or valor[contador - 1] != '.'){
        return false;
    }
    return true;
}

Endereco::Endereco(){
    valor = DEFAULT;
}

Endereco::Endereco(string valor){
    this->valor = valor;
}

void Endereco::setValor(string valor){
    if (validar(valor)){
        this->valor = valor;
    }else{
        throw invalid_argument("Argumento invalido.");
    }
}

bool Endereco::validar(string valor){
    int tamanho = valor.length();

    if(tamanho >= 5 && tamanho <= 20){
        int i = 0;

        while(valor[i] != '\0'){

            if (valor[i] >= 65 && valor[i] <= 90){
                i++;
                continue;
            }
            if (valor[i] >= 97 && valor[i] <= 122){
                i++;
                continue;
            }

            if (valor[i] >= 48 && valor[i] <= 57){
                i++;
                continue;
            }
            if (valor[i] == 46){
                i++;
                continue;
            }

            if (valor[i] == 32){
                i++;
                continue;
            }
            return false;
        }
    }else{
        return false;
    }
    return true;
}

Data::Data(){
    valor = DEFAULT;
}

Data::Data(string valor){
    this->valor = valor;
}

void Data::setValor(string valor){
    if (validar(valor)){
        this->valor = valor;
    }else{
        throw invalid_argument("Argumento invalido.");
    }
}

bool Data::validar(string valor){
    int valor_do_primeiro_caractere = 0;
    int valor_do_segundo_caractere = 0;

    valor_do_primeiro_caractere = valor[0];

    if (valor_do_primeiro_caractere < 48 or valor_do_primeiro_caractere > 51){
        return false;
    }
    valor_do_segundo_caractere = valor[1];

    if (valor_do_primeiro_caractere == 48){

        if (valor_do_segundo_caractere == 48){
            return false;
        }
    }

    if (valor_do_primeiro_caractere == 51){

        if (valor_do_segundo_caractere != 48 && valor_do_segundo_caractere != 49){
            return false;
        }
    }

    if (valor_do_segundo_caractere < 48 or valor_do_segundo_caractere > 57){
        return false;
    }

    valor_do_primeiro_caractere = valor[3];

    if (valor_do_primeiro_caractere != 48 && valor_do_primeiro_caractere != 49){
        return false;
    }
    valor_do_segundo_caractere = valor[4];

    if (valor_do_primeiro_caractere == 48){

        if (valor_do_segundo_caractere < 49 or valor_do_segundo_caractere > 57){
            return false;
        }
    }

    if (valor_do_primeiro_caractere == 49){

        if (valor_do_segundo_caractere < 48 or valor_do_segundo_caractere > 50){
            return false;
        }
    }

    valor_do_primeiro_caractere = valor[6];

    if (valor_do_primeiro_caractere < 50 or valor_do_primeiro_caractere > 57){
        return false;
    }
    valor_do_segundo_caractere = valor[7];

    if (valor_do_primeiro_caractere == 50){

        if (valor_do_segundo_caractere < 49 or valor_do_segundo_caractere > 57){
            return false;
        }
    }

    if (valor_do_segundo_caractere < 48 or valor_do_segundo_caractere > 57 or valor[8] != '\0'){
        return false;
    }
    return true;
}

Numero::Numero(){
    valor = DEFAULT;
}

Numero::Numero(int valor){
    this->valor = valor;
}

void Numero::setValor(int valor){
    if (validar(valor)){
        this->valor = valor;
    }else{
        throw invalid_argument("Argumento invalido.");
    }
}

bool Numero::validar(int valor){

    if (valor > 20 || valor < 0){
        return false;
    }
    return true;
}

Moeda::Moeda(){
    valor = DEFAULT;
}

Moeda::Moeda(double valor){
    this->valor = valor;
}

void Moeda::setValor(double valor){
    if (validar(valor)){
        this->valor = valor;
    }else{
        throw invalid_argument("Argumento invalido.");
    }
}

bool Moeda::validar(double valor){

    if(valor >= 0.00 && valor <= 1000000.00){
        return true;
    }else{
        return false;
    }
}

Nome::Nome(){
    valor = DEFAULT;
}

Nome::Nome(string valor){
    this->valor = valor;
}

void Nome::setValor(string valor){
    if (validar(valor)){
        this->valor = valor;
    }else{
        throw invalid_argument("Argumento invalido.");
    }
}

bool Nome::validar(string valor){

   int i = 0;

   int contador_primeira = 0;

   while(valor[i] != '\0'){

       while(contador_primeira == 0){

            if (valor[0] >= 65 && valor[0] <= 90){

                contador_primeira++;
            }else{

                return false;
                contador_primeira++;
            }
        }

        if (valor[i] >= 65 && valor[i] <= 90){
            i++;
            continue;
        }

        if (valor[i] >= 97 && valor[i] <= 122){
            i++;
            continue;
        }

        if (valor[i] == 46){

            if((valor[i-1] >= 65 && valor[i-1] <= 90) ||( valor[i-1] >= 97 && valor[i-1] <= 122)){
                i++;

            }else{
                i++;
                return false;
                continue;
            }
        }

        if (valor[i] == 32){

            if (valor[i+1] == 32){
                i++;
                return false;
                continue;

            }else{
                if (valor[i+1] == '\0' ){

                }

                if (valor[i+1] >= 65 && valor[i+1] <= 90){
                }else{
                    return false;
                }
                i++;
                continue;
            }

        }else{
            return false;
            i++;
            continue;
        }
    }

    if(i >= 5 && i <=25){
        return true;
    }else{
        return false;
    }
}

Email::Email(){
    valor = DEFAULT;
}

Email::Email(string valor){
    this->valor = valor;
}

void Email::setValor(string valor){
    if (validar(valor)){
        this->valor = valor;
    }else{
        throw invalid_argument("Argumento invalido.");
    }
};

bool Email::validar(string valor){

    string caractere = "a";
    int posicao = 0;
    int valor_do_caractere;
    int proximo_valor_do_caractere;
    int contador_1 = 0;

    while(caractere != "@"){
        caractere = valor[posicao];
        posicao++;
        contador_1 ++;
    }

    if(contador_1 > 10){
        return  false;
    }
    int contador_2 = 0;

    while(valor[posicao] != '\0'){
        contador_2++;
        posicao++;
    }

    if(contador_2 > 20){
        return  false;
    }

    return true;
}

Senha::Senha(){
    valor = DEFAULT;
}

Senha::Senha(string valor){
    this->valor = valor;
}

void Senha::setValor_1(string valor){
    valor.pop_back();
    if (validar(valor)){
        this->valor = valor;
    }else{
        throw invalid_argument("Argumento invalido.");
    }
}

void Senha::setValor_2(string valor){
    if (validar(valor)){
        this->valor = valor;
    }else{
        throw invalid_argument("Argumento invalido.");
    }
}

bool Senha::validar(string valor){
    size_t contador_1, contador_2;

    if (valor.length()!=6){
        cout << "Erro no tamanho da senha, deve possuir 6 caracteres" << endl;
        return false;
    }

    bool maiuscula = false;
    bool minuscula = false;
    bool numero = false;

    for (contador_1 = 0; contador_1 < valor.length(); contador_1++){
        for(contador_2 = 0; contador_2 < contador_1; contador_2++){
            if (valor[contador_1] == valor[contador_2]){
                cout << "Erro, ha caractere repetido na senha" << endl;
                return false;
            }
        }

        if (int(valor[contador_1]) > 64 && int(valor[contador_1]) < 91){
            maiuscula = true;
        }
        if (int(valor[contador_1]) > 96 && int(valor[contador_1]) < 123){
            minuscula = true;
        }
        if (int(valor[contador_1]) > 47 && int(valor[contador_1]) < 58){
            numero = true;
        }
        if (int(valor[contador_1]) < 48 || (int(valor[contador_1]) < 65 && int(valor[contador_1]) > 57) || (int(valor[contador_1]) < 97 && int(valor[contador_1]) > 90) || int(valor[contador_1]) > 122){
            cout << "Erro, ha caractere que nao e letra ou numero" << endl;
            return false;
        }
    }

    if (!maiuscula || !minuscula || !numero){
        cout << "Erro senha nao possui pelo menos uma letra minuscula e maiuscula" << endl;
        return false;
    }

    return true;
}

Telefone::Telefone(){
    valor = DEFAULT;
}

Telefone::Telefone(string valor){
    this->valor = valor;
}

void Telefone::setValor(string valor){
    if (validar(valor)){
        this->valor = valor;
    }else{
        throw invalid_argument("Argumento invalido.");
    }
}

bool Telefone::validar(string valor){
    int zeros = 0,i = 0,preFixo = 0, j = 0, k = 0, l = 0;

    if(valor[0] == '(' && valor[4] == ')' && valor[5] == '-'){
        while(valor[i] != '\0'){

            if(valor[i] == 48){
                zeros++;
            }

            if(valor[i] == 40){
                j++;
            }

            if(j > 1){
                return false;
            }

            if(valor[i] == 41){
                k++;
            }

            if(k > 1){
                return false;
            }

            if(valor[i] == 45){
                l++;
            }

            if(l > 1){
                return false;
            }

            if(zeros >= 12){
                return false;
            }

            if((valor[i] >= 48 && valor[i] <= 57 )|| valor[i] == 40 || valor[i] == 41 || valor[i] == 45){
                i++;
            }else{
                return false;
            }
        }

        if(i == 15){
        }else{
            return false;
        }
    }else{
        return false;
    }
    return true;
}
