#include <string.h>
#include <stdexcept>
#include <iostream>

#include "n_dominios.h"
#include "n_interfaces.h"
#include "n_controladorasapresentacao.h"
#include "n_stubs.h"

using namespace std;

int main()
{


    CntrApresentacaoControle *cntrApresentacaoControle;
    IApresentacaoAutenticacao *cntrApresentacaoAutenticacao;
    IApresentacaoPessoal *cntrApresentacaoPessoal;
    IApresentacaoImoveis *cntrApresentacaoImoveis;

    cntrApresentacaoControle = new CntrApresentacaoControle();
    cntrApresentacaoAutenticacao = new CntrApresentacaoAutenticacao();
    cntrApresentacaoPessoal = new CntrApresentacaoPessoal();
    cntrApresentacaoImoveis = new CntrApresentacaoImoveis();


    IServicoAutenticacao *stubServicoAutenticacao;
    IServicoPessoal *stubServicoPessoal;
    IServicoImoveis *stubServicoImoveis;

    stubServicoAutenticacao = new StubServicoAutenticacao();
    stubServicoPessoal = new StubServicoPessoal();
    stubServicoImoveis = new StubServicoImoveis();


    cntrApresentacaoControle->setCntrApresentacaoAutenticacao(cntrApresentacaoAutenticacao);
    cntrApresentacaoControle->setCntrApresentacaoPessoal(cntrApresentacaoPessoal);
    cntrApresentacaoControle->setCntrApresentacaoImoveis(cntrApresentacaoImoveis);

    cntrApresentacaoAutenticacao->setCntrServicoAutenticacao(stubServicoAutenticacao);

    cntrApresentacaoPessoal->setCntrServicoPessoal(stubServicoPessoal);
    cntrApresentacaoPessoal->setCntrServicoImoveis(stubServicoImoveis);

    cntrApresentacaoImoveis->setCntrServicoImoveis(stubServicoImoveis);

    cntrApresentacaoControle->executar();

    return 0;
}
