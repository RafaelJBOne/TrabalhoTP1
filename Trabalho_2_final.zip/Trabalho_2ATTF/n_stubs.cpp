#include "n_stubs.h"


const string StubServicoAutenticacao::INVALIDO = "12345";
const string StubServicoPessoal::INVALIDO = "12345";
const string StubServicoImoveis::INVALIDO = "12345";



bool StubServicoAutenticacao::autenticar(Email email, Senha senha){
    if(email.getValor().compare(INVALIDO) == 0)
        return false;
    return true;
}

bool StubServicoPessoal::cadastrarUsuario(Usuario usuario){
    if(usuario.getemail().getValor().compare(INVALIDO) == 0)
        return false;
    return true;
}

bool StubServicoPessoal::alterar(Usuario usuario){
    if(usuario.getemail().getValor().compare(INVALIDO) == 0)
        return false;
    return true;
}

bool StubServicoImoveis::cadastrarImovel(Codigo codigo){
    if(codigo.getValor().compare(INVALIDO) == 0)
        return false;
    return true;
}

bool StubServicoImoveis::descadastrarImovel(Codigo codigo){
    if(codigo.getValor().compare(INVALIDO) == 0)
        return false;
    return true;
}

bool StubServicoImoveis::editarDadosDeImovel(Codigo codigo){
    if(codigo.getValor().compare(INVALIDO) == 0)
        return false;
    return true;
}
